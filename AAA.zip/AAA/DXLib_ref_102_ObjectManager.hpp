#pragma once
#include "DXLib_ref_103_ObjectBase.hpp"

namespace DXLibRef {
	class ObjectBaseClass;

	using SharedObj = std::shared_ptr<ObjectBaseClass>;

	class ObjectManager : public SingletonBase<ObjectManager> {
	private:
		friend class SingletonBase<ObjectManager>;
	private:
		std::vector<SharedObj>		m_Object;
		int							m_LastUniqueID{ 0 };
		switchs						m_ResetP;
	private:
		ObjectManager(void) noexcept {
			this->m_Object.reserve(256);
		}
		ObjectManager(const ObjectManager&) = delete;
		ObjectManager(ObjectManager&& o) = delete;
		ObjectManager& operator=(const ObjectManager&) = delete;
		ObjectManager& operator=(ObjectManager&& o) = delete;

		~ObjectManager(void) noexcept {
			DeleteAll();
			this->m_Object.shrink_to_fit();
		}
	public:
		void			AddObject(const SharedObj& NewObj) noexcept;
		SharedObj* GetObj(int ModelType, int num) noexcept;
		void			DelObj(SharedObj* ptr) noexcept;

	public:
		void			ExecuteObject(void) noexcept;
		void			LateExecuteObject(void) noexcept;
		void			Draw(void) noexcept;
		void			DeleteAll(void) noexcept;
	};
};
