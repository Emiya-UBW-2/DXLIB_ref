#pragma once
#include "DXLib_ref.h"

namespace DXLibRef {
	class ObjectBaseClass {
	protected:
		std::string									m_FilePath;
		std::string									m_ObjFileName;
		std::string									m_ColFileName;
		int											m_ObjectID{ InvalidID };
		moves										m_move;
		int											m_objType{ 0 };
		bool										m_IsActive{ true };
		bool										m_IsDelete{ false };
		bool										m_IsFirstLoop{ true };
	public:
		// 
		const auto& GetFilePath(void) const noexcept { return this->m_FilePath; }
		auto& SetMove(void) noexcept { return this->m_move; }
	public:
		const auto& GetObjectID(void) const noexcept { return this->m_ObjectID; }
		const auto& GetobjType(void) const noexcept { return this->m_objType; }
		const auto& GetMove(void) const noexcept { return this->m_move; }
		const auto& IsActive(void) const noexcept { return this->m_IsActive; }
		const auto& GetIsDelete(void) const noexcept { return this->m_IsDelete; }
		auto		GetPathCompare(const char* filepath, const char* objfilename, const char* colfilename) const noexcept {
			return ((this->m_FilePath == filepath) && (this->m_ObjFileName == objfilename) && (this->m_ColFileName == colfilename));
		}
	public:
		void				SetObjectID(int value) noexcept { this->m_ObjectID = value; }
		void				SetActive(bool value) noexcept { this->m_IsActive = value; }
		void				SetDelete(void) noexcept { this->m_IsDelete = true; }
		void				ResetMove(const Matrix3x3DX& RotMat, const Vector3DX& pos) noexcept {
			this->m_move.SetVec(Vector3DX::zero());
			this->m_move.SetMat(RotMat);
			this->m_move.SetPos(pos);
			this->m_move.Update(0.f, 0.f);
		}
	public:
		virtual int	GetFrameNum(void) noexcept { return 0; }
		virtual const char* GetFrameStr(int) noexcept { return nullptr; }

		virtual int	GetMaterialNum(void) noexcept { return 0; }
		virtual const char* GetMaterialStr(int) noexcept { return nullptr; }

		virtual int	GetShapeNum(void) noexcept { return 0; }
		virtual const char* GetShapeStr(int) noexcept { return nullptr; }
	public:
		ObjectBaseClass(void) noexcept {}
		ObjectBaseClass(const ObjectBaseClass&) = delete;
		ObjectBaseClass(ObjectBaseClass&& o) = delete;
		ObjectBaseClass& operator=(const ObjectBaseClass&) = delete;
		ObjectBaseClass& operator=(ObjectBaseClass&& o) = delete;

		virtual ~ObjectBaseClass(void) noexcept {}
	public:
		void			Init(void) noexcept {
			this->m_IsActive = true;
			this->m_IsFirstLoop = true;
			Init_Sub();
		}
		virtual void	FirstExecute(void) noexcept {}
		void			ExecuteCommon(void) noexcept {
			if (this->m_IsFirstLoop) {
			}
			// �ŏ��̃��[�v�I���
			this->m_IsFirstLoop = false;
		}
		virtual void	LateExecute(void) noexcept {}
		virtual void	Draw(void) noexcept {
			if (this->m_IsActive) {
			}
		}
		void			Dispose(void) noexcept { Dispose_Sub(); }
	protected:
		virtual void	Init_Sub(void) noexcept {}
		virtual void	Dispose_Sub(void) noexcept {}
	};
};
