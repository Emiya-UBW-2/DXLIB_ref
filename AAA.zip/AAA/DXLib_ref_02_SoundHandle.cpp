﻿#include "DXLib_ref_02_SoundHandle.hpp"

namespace DXLibRef {
	// シングルトンの実態定義
	const SoundPool* SingletonBase<SoundPool>::m_Singleton = nullptr;
	const BGMPool* SingletonBase<BGMPool>::m_Singleton = nullptr;
	// --------------------------------------------------------------------------------------------------
	// 
	// --------------------------------------------------------------------------------------------------
};
