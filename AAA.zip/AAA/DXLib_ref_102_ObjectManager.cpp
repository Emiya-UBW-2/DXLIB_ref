#include "DXLib_ref_102_ObjectManager.hpp"

namespace DXLibRef {
	// �V���O���g���̎��Ԓ�`
	const ObjectManager* SingletonBase<ObjectManager>::m_Singleton = nullptr;
	// --------------------------------------------------------------------------------------------------
	// 
	// --------------------------------------------------------------------------------------------------
	void			ObjectManager::AddObject(const SharedObj& NewObj) noexcept {
		this->m_Object.emplace_back(NewObj);
		this->m_Object.back()->SetObjectID(this->m_LastUniqueID);
		++this->m_LastUniqueID;
	}
	SharedObj* ObjectManager::GetObj(int ModelType, int num) noexcept {
		int cnt = 0;
		for (auto& o : this->m_Object) {
			if (o->GetobjType() == ModelType) {
				if (cnt == num) {
					return &o;
				}
				++cnt;
			}
		}
		return nullptr;
	}
	void			ObjectManager::DelObj(SharedObj* ptr) noexcept {
		for (size_t index = 0; auto & o : this->m_Object) {
			if (o == *ptr) {
				// ���Ԃ̈ێ��̂��߂�����erase
				o->Dispose();
				this->m_Object.erase(this->m_Object.begin() + index);
				break;
			}
			index++;
		}
	}
	void			ObjectManager::ExecuteObject(void) noexcept {
		// �I�u�W�F�N�g���������ꍇ�ɔ����Ĕ͈�for�͎g��Ȃ�
		for (int i : std::views::iota(0, static_cast<int>(this->m_Object.size()))) {
			auto& o = this->m_Object.at(static_cast<size_t>(i));
			if (!o->GetIsDelete()) {
				o->FirstExecute();
			}
		}
		// �I�u�W�F�N�g�̔r���`�F�b�N
		for (int i = 0, Max = static_cast<int>(this->m_Object.size()); i < Max; i++) {
			auto& o = this->m_Object.at(static_cast<size_t>(i));
			if (o->GetIsDelete()) {
				// ���Ԃ̈ێ��̂��߂�����erase
				o->Dispose();
				this->m_Object.erase(this->m_Object.begin() + i);
				i--;
				Max--;
			}
		}
	}
	void			ObjectManager::LateExecuteObject(void) noexcept {
		for (auto& o : this->m_Object) {
			o->LateExecute();
		}
	}
	void			ObjectManager::Draw(void) noexcept {
		for (auto& o : this->m_Object) {
			o->Draw();
		}
	}
	void			ObjectManager::DeleteAll(void) noexcept {
		for (auto& o : this->m_Object) {
			if (o) {
				o->Dispose();
			}
		}
		this->m_Object.clear();
		this->m_LastUniqueID = 0;// ��U���j�[�NID�����Z�b�g
	}
};
