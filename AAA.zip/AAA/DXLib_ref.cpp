﻿#include "DXLib_ref.h"

namespace DXLibRef {
	// シングルトンの実態定義
	const DXLib_ref* SingletonBase<DXLib_ref>::m_Singleton = nullptr;
	// コンストラクタ
	DXLib_ref::DXLib_ref(void) noexcept {
		// ローカライズ制御クラスの生成
		LocalizePool::Create();
		//オプションデータ制御クラスの生成
		OPTION::Create();
		//セーブデータ制御クラスの生成
		SaveDataClass::Create();
		auto* SaveDataParts = SaveDataClass::Instance();
		auto* OptionParts = OPTION::Instance();
		//セーブデータのロード
		m_IsFirstBoot = !SaveDataParts->Load();
		//ロードするデータがない場合初回と判定
		if (m_IsFirstBoot) {
			// 初回データ作成のためセーブ
			SaveDataParts->Save();
		}
		// ウィンドウ等制御クラスの生成
		DXDraw::Create();
		// デバッグ制御クラスの生成
#if DEBUG
		DebugClass::Create();
#endif // DEBUG
		//SE制御クラスの生成
		SoundPool::Create();
		//BGM制御クラスの生成
		BGMPool::Create();
		//フォント制御クラスの生成
		FontPool::Create();
		//キー、パッド、キーガイド制御クラスの生成
		PadControl::Create();
		//オプション画面制御クラスの生成
		OptionWindowClass::Create();
		//オブジェクト制御クラスの生成
		ObjectManager::Create();
		//サイドログ制御クラスの生成
		SideLog::Create();
		//ポップアップ制御クラスの生成
		PopUp::Create();
		//UI画面制御クラスの生成
		WindowSystem::DrawControl::Create();
		//UI用の共通SEを読み込み
		auto* SE = SoundPool::Instance();
		SE->Add(static_cast<int>(SoundEnumCommon::UI_Select), 2, "CommonData/Sound/UI/cursor.wav", false);
		SE->Add(static_cast<int>(SoundEnumCommon::UI_CANCEL), 1, "CommonData/Sound/UI/cancel.wav", false);
		SE->Add(static_cast<int>(SoundEnumCommon::UI_OK), 1, "CommonData/Sound/UI/ok.wav", false);
		SE->Add(static_cast<int>(SoundEnumCommon::UI_NG), 1, "CommonData/Sound/UI/ng.wav", false);
		//SE音量にボリュームを反映
		SE->SetVol(OptionParts->GetParamFloat(EnumSaveParam::SE));
	}
	//初回設定画面
	void DXLib_ref::InitFirstBootSetting(void) noexcept {
		auto* OptionWindowParts = OptionWindowClass::Instance();
		// タイトル切り替え
		SetMainWindowText("FirstBoot Option");
		// PCスペックをチェック
		m_CheckPCSpec.Set();
		m_CheckPCSpec.StartSearch();
		// オプション画面を開く
		OptionWindowParts->SetActive();
	}
	void DXLib_ref::UpdateFirstBootSetting(void) noexcept {
		auto* DrawParts = DXDraw::Instance();
		//ウィンドウサイズを更新
		int xBase = DrawParts->GetUIY(1366);
		int yBase = DrawParts->GetUIY(768);
		SetWindowPosition((deskx - xBase) / 2, (desky - yBase) / 2);
		SetWindowSize(xBase, yBase);
	}
	void DXLib_ref::DrawFirstBootSetting(void) const noexcept {
		auto* DrawParts = DXDraw::Instance();
		auto* Pad = PadControl::Instance();
		auto* PopUpParts = PopUp::Instance();
		auto* LocalizeParts = LocalizePool::Instance();
		auto* OptionParts = OPTION::Instance();

		int xBase = DrawParts->GetUIY(1366);
		//int yBase = DrawParts->GetUIY(768);
		int Width = DrawParts->GetUIY(720);
		int Height = DrawParts->GetUIY(720);
		int Edge = DrawParts->GetUIY(16);

		PopUpParts->Draw(Width / 2 + Edge, Height / 2 + Edge);

		WindowSystem::SetMsg(Edge + Edge, Height + Edge + Edge, DrawParts->GetUIY(12), FontHandle::FontXCenter::LEFT, Green, Black, LocalizeParts->Get(109));

		int xp = Width + Edge + Edge;
		int yp = Edge;
		yp += DrawParts->GetUIY(24);
		if (m_CheckPCSpec.GetCPUDatas()) {
			int MouseOverID = InvalidID;
			// CPU
			WindowSystem::SetMsg(xp, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, DarkGreen, LocalizeParts->Get(2001)); yp += LineHeight;
			for (auto& c : *m_CheckPCSpec.GetCPUDatas()) {
				int TextID = 0;
				unsigned int Color = White;
				if (c.m_Score >= 17276) {// 
					Color = Green;
					TextID = 2002;
				}
				else if (c.m_Score >= 6600) {// 
					Color = Yellow;
					TextID = 2003;
				}
				else {// 
					Color = Red;
					TextID = 2004;
				}
				if (IntoMouse(xp + Edge, yp, xBase - Edge, yp + LineHeight * 2)) {
					switch (TextID) {
					case 2002:
						MouseOverID = 2040;
						break;
					case 2003:
						MouseOverID = 2041;
						break;
					case 2004:
						MouseOverID = 2042;
						break;
					default:
						break;
					}
				}
				WindowSystem::SetMsg(xp + Edge, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, DarkGreen, "[%s]", c.m_Name.c_str());
				WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight * 2 / 3, FontHandle::FontXCenter::RIGHT, Color, DarkGreen, "%s", LocalizeParts->Get(TextID)); yp += LineHeight;
				WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::RIGHT, White, DarkGreen, "PassMark Score:%d", c.m_Score); yp += LineHeight;
				yp += LineHeight;
			}
			if (m_CheckPCSpec.GetCPUDatas()->size() == 0) {
				WindowSystem::SetMsg(xp, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, Red, DarkGreen, LocalizeParts->Get(2005)); yp += LineHeight;
			}
			// Mem
			{
				WindowSystem::SetMsg(xp, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, DarkGreen, LocalizeParts->Get(2011)); yp += LineHeight;
				WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, DarkGreen, "[%4.3lfMB / %4.3lfMB]", m_CheckPCSpec.GetFreeMemorySize(), m_CheckPCSpec.GetTotalMemorySize());
				int TextID = 0;
				unsigned int Color = White;
				if ((m_CheckPCSpec.GetTotalMemorySize() - m_CheckPCSpec.GetFreeMemorySize()) >= 2000) {// 
					Color = Green;
					TextID = 2012;
				}
				else {// 
					Color = Yellow;
					TextID = 2013;
				}
				if (IntoMouse(xp + Edge, yp, xBase - Edge, yp + LineHeight * 1)) {
					switch (TextID) {
					case 2012:
						MouseOverID = 2043;
						break;
					case 2013:
						MouseOverID = 2044;
						break;
					default:
						break;
					}
				}
				WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight * 2 / 3, FontHandle::FontXCenter::RIGHT, Color, DarkGreen, "%s", LocalizeParts->Get(TextID)); yp += LineHeight;
				yp += LineHeight;
			}
			// GPU
			WindowSystem::SetMsg(xp, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, DarkGreen, LocalizeParts->Get(2021)); yp += LineHeight;
			for (auto& c : *m_CheckPCSpec.GetGPUDatas()) {
				int TextID = 0;
				unsigned int Color = White;
				if (c.m_Score >= 14649) {// 
					Color = Green;
					TextID = 2022;
				}
				else if (c.m_Score >= 5003) {// 
					Color = Yellow;
					TextID = 2023;
				}
				else {// 
					Color = Red;
					TextID = 2024;
				}
				if (IntoMouse(xp + Edge, yp, xBase - Edge, yp + LineHeight * 2)) {
					switch (TextID) {
					case 2022:
						MouseOverID = 2045;
						break;
					case 2023:
						MouseOverID = 2046;
						break;
					case 2024:
						MouseOverID = 2047;
						break;
					default:
						break;
					}
				}
				WindowSystem::SetMsg(xp + Edge, yp + LineHeight / 2, LineHeight * 3 / 4, FontHandle::FontXCenter::LEFT, White, DarkGreen, "%s", c.m_Name.c_str());
				WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight * 2 / 3, FontHandle::FontXCenter::RIGHT, Color, DarkGreen, "%s", LocalizeParts->Get(TextID)); yp += LineHeight;
				WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::RIGHT, White, DarkGreen, "PassMark Score:%d", c.m_Score); yp += LineHeight;
				yp += LineHeight;
			}
			if (m_CheckPCSpec.GetGPUDatas()->size() == 0) {
				WindowSystem::SetMsg(xp, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, Red, DarkGreen, LocalizeParts->Get(2025)); yp += LineHeight;
			}
			// DirectX
			int NowSet = OptionParts->GetParamInt(EnumSaveParam::DirectXVer);
			for (int loop : std::views::iota(0, 2)) {
				if (GetUseDirect3DVersion() == DirectXVerID[loop]) {
					NowSet = loop;
				}
			}
			if (IntoMouse(xp + Edge, yp, xBase - Edge, yp + LineHeight * 2)) {
				MouseOverID = 2048;
			}
			WindowSystem::SetMsg(xp, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, DarkGreen, LocalizeParts->Get(2035));
			WindowSystem::SetMsg(xBase - Edge, yp + LineHeight / 2, LineHeight, FontHandle::FontXCenter::RIGHT, White, DarkGreen, "DirectX%s", DirectXVerStr[NowSet]); yp += LineHeight;
			if (MouseOverID != InvalidID) {
				xp = Pad->GetMS_X();
				yp = Pad->GetMS_Y();
				WindowSystem::SetMsg(xp, yp - LineHeight / 2, LineHeight, FontHandle::FontXCenter::RIGHT, Green, DarkGreen, LocalizeParts->Get(MouseOverID));
			}
		}

		xp = Width + Edge + Edge + Edge;
		yp = Height;
		if (WindowSystem::SetMsgClickBox(xp, yp, xBase - Edge + Edge, yp + Edge + Edge, LineHeight, Green, false, true, "Start Game!")) {
			PopUpParts->EndAll();
		}
	}
	// ポーズ画面
	void DXLib_ref::UpdatePause(void) noexcept {
		auto* DrawParts = DXDraw::Instance();
		//ポーズ画面に入っていない場合はスルーする
		if (!IsPause()) {
			return;
		}
		//1秒経ったら0秒にリセットする
		m_PauseFlashCount += DrawParts->GetDeltaTime();
		if (m_PauseFlashCount > 1.f) {
			m_PauseFlashCount -= 1.f;
		}
	}
	void DXLib_ref::DrawPause(void) const noexcept {
		auto* DrawParts = DXDraw::Instance();
		auto* DrawCtrls = WindowSystem::DrawControl::Instance();
		//ポーズ画面に入っていない場合はスルーする
		if (!IsPause()) {
			return;
		}
		// 半透明の暗幕
		DrawCtrls->SetAlpha(WindowSystem::DrawLayer::Normal, 128);
		DrawCtrls->SetDrawBox(WindowSystem::DrawLayer::Normal, 0, 0, DrawParts->GetUIXMax(), DrawParts->GetUIYMax(), Black, TRUE);
		DrawCtrls->SetAlpha(WindowSystem::DrawLayer::Normal, 255);
		// カウントが0.5秒以上であれば Pause の文字を表示
		if (m_PauseFlashCount > 0.5f) {
			WindowSystem::SetMsg(DrawParts->GetUIY(16), DrawParts->GetUIY(16) + DrawParts->GetUIY(36) / 2, DrawParts->GetUIY(36), FontHandle::FontXCenter::LEFT, Green, Black, "Pause");
		}
	}
	// FPS表示
	void DXLib_ref::InitFPSCounter(void) noexcept {
		// 各々の数値を初期化
		for (auto& f : FPSAvgs) {
			f = FrameRate;
		}
		m_FPSAvgCount = 0;
	}
	void DXLib_ref::UpdateFPSCounter(void) noexcept {
		auto* DrawParts = DXDraw::Instance();
		//m_FPSAvgCountの番号に対して今のフレームレートを保存
		FPSAvgs.at(m_FPSAvgCount) = DrawParts->GetFps();
		//保存する場所をずらす
		++m_FPSAvgCount %= FPSAvgs.size();
		//保存している過去のFPS値の平均をとる
		m_FPSAvg = 0.f;
		for (auto& f : FPSAvgs) {
			m_FPSAvg += f;
		}
		m_FPSAvg = m_FPSAvg / static_cast<float>(FPSAvgs.size());
	}
	void DXLib_ref::DrawFPSCounter(void) const noexcept {
		auto* DrawParts = DXDraw::Instance();
		auto* OptionParts = OPTION::Instance();
		// FPSの平均値が設定していた上限値に対して高いなら緑、低いなら黄色赤色と変化させる
		auto color = White;
		if (m_FPSAvg > static_cast<float>(OptionParts->GetParamInt(EnumSaveParam::FpsLimit) - 2)) {
			color = Green;//十分にFPSが出ている
		}
		else if (m_FPSAvg > static_cast<float>(OptionParts->GetParamInt(EnumSaveParam::FpsLimit) - 10)) {
			color = Yellow;//十分にFPSが出ていない
		}
		else {
			color = Red;//まったくFPSが出ていない
		}
		//FPS値の表示
		WindowSystem::SetMsg(DrawParts->GetUIXMax() - DrawParts->GetUIY(8), DrawParts->GetUIY(8) + LineHeight / 2, LineHeight, FontHandle::FontXCenter::RIGHT, color, Black, "%5.2f FPS", m_FPSAvg);
		//ドローコール(DirectXに何回描画指示を送ったか)の表示
		WindowSystem::SetMsg(DrawParts->GetUIXMax() - DrawParts->GetUIY(8), DrawParts->GetUIY(8 + 20) + LineHeight / 2, LineHeight, FontHandle::FontXCenter::RIGHT, White, Black, "%d Drawcall", GetDrawCallCount());
	}
	void DXLib_ref::SetPause(bool value) noexcept {
		auto* Pad = PadControl::Instance();
		if (value != IsPause()) {
			m_PauseActive.Execute(true);
			Pad->SetGuideUpdate();
		}
	}
	// 初回の設定画面ループ
	void DXLib_ref::FirstBootSetting(void) noexcept {
		auto* DrawParts = DXDraw::Instance();
		auto* OptionWindowParts = OptionWindowClass::Instance();
		auto* Pad = PadControl::Instance();
		auto* PopUpParts = PopUp::Instance();
		auto* OptionParts = OPTION::Instance();
		auto* DrawCtrls = WindowSystem::DrawControl::Instance();
		//初期化
		InitFirstBootSetting();
		//メインループ開始
		while (true) {
			//プロセスからのメッセージが届かない場合異常事態として強制終了
			if (!(ProcessMessage() == 0)) { return; }
			//ループ初回の更新
			DrawParts->StartCount();
			//UI描画リストをクリア
			DrawCtrls->ClearList();
			//初回設定画面の更新
			UpdateFirstBootSetting();
			//操作のアップデート
			Pad->Update();
			//オプション画面のアップデート
			OptionWindowParts->Update();
			//ポップアップのアップデート
			PopUpParts->Update();
			//ポップアップが閉じた場合ループを抜ける(終了)
			if (!PopUpParts->IsActivePop()) {
				break;
			}
			//裏画面をクリアして描画先に設定
			GraphHandle::SetDraw_Screen(static_cast<int>(DX_SCREEN_BACK), true);
			{
				//UI描画設定を行い
				DrawFirstBootSetting();
				//結果を描画
				DrawCtrls->Draw();
			}
			//表画面に反映し、垂直同期または一定のFPSまで待機する
			DrawParts->Screen_Flip();
		}
		//終わったらセーブ
		OptionParts->Save();
		//別プロセスとして自身を起動しておく
		StartMe();
	}
	// ロジック開始時に通る
	bool DXLib_ref::StartLogic(void) noexcept {
		auto* OptionWindowParts = OptionWindowClass::Instance();
		// オプション画面の初期化
		OptionWindowParts->Init();
		// ポーズはオフ状態として初期化
		m_PauseActive.Set(false);
		// 初回であれば
		if (m_IsFirstBoot) {
			// 初回設定を開いて
			FirstBootSetting();
			//終了次第ゲームを終了する
			return false;
		}
		// ポストプロセス制御の生成
		PostPassEffect::Create();
		// シーン遷移制御の生成
		SceneControl::Create();
		return true;
	}
	// メインループやシーン遷移管理を行う
	bool DXLib_ref::MainLogic(void) noexcept {
		auto* SceneParts = SceneControl::Instance();
		auto* DrawParts = DXDraw::Instance();
		auto* Pad = PadControl::Instance();
		auto* PopUpParts = PopUp::Instance();
		auto* OptionWindowParts = OptionWindowClass::Instance();
		auto* LocalizeParts = LocalizePool::Instance();
		auto* PostPassParts = PostPassEffect::Instance();
		auto* SideLogParts = SideLog::Instance();
		auto* DrawCtrls = WindowSystem::DrawControl::Instance();
#if DEBUG
		auto* DebugParts = DebugClass::Instance();
#endif // DEBUG
		// 一連のシーンループを開始
		while (true) {
			//シーンのロード
			SceneParts->GetNowScene()->Load();
			//シーンの初回処理
			SceneParts->GetNowScene()->Set();
			//シーン開始時にキーガイド表示の更新を行うフラグを立てる
			Pad->SetGuideUpdate();
			//FPS表示の初期化
			InitFPSCounter();
			//メインループ開始
			while (true) {
				//プロセスからのメッセージが届かない場合異常事態として強制終了
				if (!(ProcessMessage() == 0)) { return false; }
				//ループ初回の更新
				DrawParts->StartCount();
#if DEBUG
				//DXLIBのメッセージ表示をクリア
				clsDx();
				//デバッグの計測開始位置をここに指定
				DebugParts->SetStartPoint();
#endif // DEBUG
				//UI描画リストをクリア
				DrawCtrls->ClearList();
				//終了キーを押し、尚且つ終了ウィンドウが出ていない場合
				if (Pad->GetEsc().trigger() && !m_IsExitSelect) {
					//終了ウィンドウフラグを立てて
					m_IsExitSelect = true;
					//終了ポップアップを表示
					PopUpParts->Add(LocalizeParts->Get(100), 480, 240,
						[this](int xmin, int ymin, int xmax, int ymax, bool) {
							//ポップアップ内で描画するもの
							auto* DrawParts = DXDraw::Instance();
							auto* LocalizeParts = LocalizePool::Instance();
							int xp1, yp1;
							// タイトル
							{
								xp1 = xmin + DrawParts->GetUIY(24);
								yp1 = ymin + LineHeight;

								WindowSystem::SetMsg(xp1, yp1 + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, Black, LocalizeParts->Get(101));
							}
							// 終了するボタン
							{
								xp1 = (xmax + xmin) / 2 - DrawParts->GetUIY(54);
								yp1 = ymax - LineHeight * 3;

								auto* Pad = PadControl::Instance();
								bool ret = WindowSystem::SetMsgClickBox(xp1, yp1, xp1 + DrawParts->GetUIY(108), yp1 + LineHeight * 2, LineHeight, Gray15, false, true, LocalizeParts->Get(102));
								if (Pad->GetKey(PADS::INTERACT).trigger() || ret) {
									//終了フラグを立てる
									this->m_IsEnd = true;
								}
							}
						},
						[this]() {
							//ポップアップが閉じるボタン等で終了した際に行うもの
							m_IsExitSelect = false;
						},
						[]() {/*ガイド表示に追加するもの。ここでは特に表示しない*/},
						true
					);
				}
				//再起動フラグが立ち、尚且つ再起動ポップアップが出ていない場合
				if (OptionWindowParts->IsRestartSwitch() && !m_IsRestartSelect) {
					m_IsRestartSelect = true;
					PopUpParts->Add(LocalizeParts->Get(100), 480, 240,
						[this](int xmin, int ymin, int xmax, int ymax, bool) {
							//ポップアップ内で描画するもの
							auto* DrawParts = DXDraw::Instance();
							auto* LocalizeParts = LocalizePool::Instance();
							int xp1, yp1;
							// タイトル
							{
								xp1 = xmin + DrawParts->GetUIY(24);
								yp1 = ymin + LineHeight;

								WindowSystem::SetMsg(xp1, yp1 + LineHeight / 2, LineHeight, FontHandle::FontXCenter::LEFT, White, Black, LocalizeParts->Get(2101));
							}
							// 終了するボタン
							{
								xp1 = (xmax + xmin) / 2 - DrawParts->GetUIY(54);
								yp1 = ymax - LineHeight * 3;

								auto* Pad = PadControl::Instance();
								bool ret = WindowSystem::SetMsgClickBox(xp1, yp1, xp1 + DrawParts->GetUIY(108), yp1 + LineHeight * 2, LineHeight, Gray15, false, true, LocalizeParts->Get(2102));
								if (Pad->GetKey(PADS::INTERACT).trigger() || ret) {
									//終了フラグを立てる
									this->m_IsEnd = true;
									//別プロセスとして自身を起動しておく
									StartMe();
								}
							}
						},
						[this]() {
							//ポップアップが閉じるボタン等で終了した際に行うもの
							m_IsRestartSelect = false;
						},
						[]() {/*ガイド表示に追加するもの。ここでは特に表示しない*/},
						true
					);
				}
				//終了フラグが経った場合即終了
				if (m_IsEnd) {
					return false;
				}
				//操作のアップデート
				Pad->Update();
				//シーンの更新
				auto IsEndScene = !SceneParts->GetNowScene()->Update();
				//オプション画面のアップデート
				OptionWindowParts->Update();
				//ウィンドウ制御等の更新
				m_PauseActive.Execute(Pad->GetKey(PADS::INVENTORY).press() && !OptionWindowParts->IsActive());
				if (m_PauseActive.trigger()) {
					Pad->SetGuideUpdate();//開閉の際にガイドアップデートフラグをオンにしておく
				}
				//ポストプロセス処理の更新
				PostPassParts->Update();
				//サイドログの更新
				SideLogParts->Update();
				//ポップアップのアップデート
				PopUpParts->Update();
				//ポーズ画面の更新
				UpdatePause();
				//FPS表示機能の更新
				UpdateFPSCounter();
				// 描画
#if DEBUG
				DebugParts->SetPoint("-----DrawStart-----");
#endif // DEBUG
				// ポストプロセス用のバッファー画面に反映
				PostPassParts->GetBufferScreen().SetDraw_Screen();
				{
					//ワールド空間の描画
					SceneParts->GetNowScene()->MainDraw();
				}
				// ポストプロセス
				PostPassParts->DrawPostProcess();
				//裏画面をクリアして描画先に設定
				GraphHandle::SetDraw_Screen(static_cast<int>(DX_SCREEN_BACK), true);
				{
					//バイリニアフィルターをかけてポストプロセス処理後のバッファー画面を描画
					int Prev = GetDrawMode();
					// SetDrawMode(DX_DRAWMODE_NEAREST);
					SetDrawMode(DX_DRAWMODE_BILINEAR);
					PostPassParts->GetBufferScreen().DrawExtendGraph(0, 0, DrawParts->GetUIXMax(), DrawParts->GetUIYMax(), false);
					SetDrawMode(Prev);

					//UI描画設定
					SceneParts->GetNowScene()->DrawUI_Base();
					// ポーズ描画を設定
					DrawPause();
					// FPS表示描画を設定
					DrawFPSCounter();
					// キーガイド描画を設定
					Pad->Draw();
					// サイドログ描画を設定
					SideLogParts->Draw();
					// ポップアップ描画を画面中央をセンターとして設定
					PopUpParts->Draw(DrawParts->GetUIXMax() / 2, DrawParts->GetUIYMax() / 2);
					//ポーズ画面の前などに描画するUIの描画設定
					SceneParts->GetNowScene()->DrawUI_In();
#if DEBUG
					//デバッグ画面描画を設定
					DebugParts->DebugWindow(DrawParts->GetUIXMax() - DrawParts->GetUIY(350), DrawParts->GetUIY(150));
#endif // DEBUG
					//結果を描画
					DrawCtrls->Draw();
				}
#if DEBUG
				// デバッグ計測の終了点を設定
				DebugParts->SetEndPoint();
#endif // DEBUG
				//表画面に反映し、垂直同期または一定のFPSまで待機する
				DrawParts->Screen_Flip();
				//シーンの終了判定が立っているのでループを抜ける
				if (IsEndScene) {
					break;
				}
			}
			// 次のシーンへ移行
			SceneParts->NextScene();
			// キーガイド描画物の破棄
			Pad->Dispose();
		}
		return true;
	}
};
